import csv

# Because of foreign key constraint, you can't update c_personid in BIOG_MAIN
update_sql_list = []
ALTNAME_DATA = "UPDATE IGNORE ALTNAME_DATA SET c_personid = %s WHERE c_personid = %s;"
ASSOC_DATA_1 = "UPDATE IGNORE ASSOC_DATA SET c_personid = %s WHERE c_personid = %s;"
ASSOC_DATA_2 = "UPDATE IGNORE ASSOC_DATA SET c_kin_id = %s WHERE c_kin_id = %s;"
ASSOC_DATA_3 = "UPDATE IGNORE ASSOC_DATA SET c_assoc_id = %s WHERE c_assoc_id = %s;"
ASSOC_DATA_4 = "UPDATE IGNORE ASSOC_DATA SET c_assoc_kin_id = %s WHERE c_assoc_kin_id = %s;"
BIOG_ADDR_DATA = "UPDATE IGNORE BIOG_ADDR_DATA SET c_personid = %s WHERE c_personid = %s;"
BIOG_INST_DATA = "UPDATE IGNORE BIOG_INST_DATA SET c_personid = %s WHERE c_personid = %s;"
BIOG_SOURCE_DATA = "UPDATE IGNORE BIOG_SOURCE_DATA SET c_personid = %s WHERE c_personid = %s;"
ENTRY_DATA = "UPDATE IGNORE ENTRY_DATA SET c_personid = %s WHERE c_personid = %s;"
KIN_DATA_1 = "UPDATE IGNORE KIN_DATA SET c_personid = %s WHERE c_personid = %s;"
KIN_DATA_2 = "UPDATE IGNORE KIN_DATA SET c_kin_id = %s WHERE c_kin_id = %s;"
POSTED_TO_ADDR_DATA = "UPDATE IGNORE POSTED_TO_ADDR_DATA SET c_personid = %s WHERE c_personid = %s;"
POSTED_TO_OFFICE_DATA = "UPDATE IGNORE POSTED_TO_OFFICE_DATA SET c_personid = %s WHERE c_personid = %s;"
POSTING_DATA = "UPDATE IGNORE POSTING_DATA SET c_personid = %s WHERE c_personid = %s;"
STATUS_DATA = "UPDATE IGNORE STATUS_DATA SET c_personid = %s WHERE c_personid = %s;"
TEXT_DATA = "UPDATE IGNORE BIOG_TEXT_DATA SET c_personid = %s WHERE c_personid = %s;"
# BIOG_MAIN = "UPDATE IGNORE BIOG_MAIN SET c_personid = %s WHERE c_personid = %s;"
update_sql_list = [ALTNAME_DATA, ASSOC_DATA_1, ASSOC_DATA_2, ASSOC_DATA_3, ASSOC_DATA_4, BIOG_ADDR_DATA, BIOG_INST_DATA, BIOG_SOURCE_DATA, ENTRY_DATA, KIN_DATA_1, KIN_DATA_2, POSTED_TO_ADDR_DATA, POSTED_TO_OFFICE_DATA, POSTING_DATA, STATUS_DATA, TEXT_DATA]

# biog_main must be placed at the end of this list
delete_sql_list = []
ALTNAME_DATA = "DELETE FROM ALTNAME_DATA WHERE c_personid = %s;"
ASSOC_DATA_1 = "DELETE FROM ASSOC_DATA WHERE c_personid = %s;"
ASSOC_DATA_2 = "DELETE FROM ASSOC_DATA WHERE c_kin_id = %s;"
ASSOC_DATA_3 = "DELETE FROM ASSOC_DATA WHERE c_assoc_id = %s;"
ASSOC_DATA_4 = "DELETE FROM ASSOC_DATA WHERE c_assoc_kin_id = %s;"
BIOG_ADDR_DATA = "DELETE FROM BIOG_ADDR_DATA WHERE c_personid = %s;"
BIOG_INST_DATA = "DELETE FROM BIOG_INST_DATA WHERE c_personid = %s;"
BIOG_SOURCE_DATA = "DELETE FROM BIOG_SOURCE_DATA WHERE c_personid = %s;"
ENTRY_DATA = "DELETE FROM ENTRY_DATA WHERE c_personid = %s;"
KIN_DATA_1 = "DELETE FROM KIN_DATA WHERE c_personid = %s;"
KIN_DATA_2 = "DELETE FROM KIN_DATA WHERE c_kin_id = %s;"
POSTED_TO_ADDR_DATA = "DELETE FROM POSTED_TO_ADDR_DATA WHERE c_personid = %s;"
POSTED_TO_OFFICE_DATA = "DELETE FROM POSTED_TO_OFFICE_DATA WHERE c_personid = %s;"
POSTING_DATA = "DELETE FROM POSTING_DATA WHERE c_personid = %s;"
STATUS_DATA = "DELETE FROM STATUS_DATA WHERE c_personid = %s;"
TEXT_DATA = "DELETE FROM BIOG_TEXT_DATA WHERE c_personid = %s;"
BIOG_MAIN = "DELETE FROM BIOG_MAIN WHERE c_personid = %s;"
delete_sql_list = [ALTNAME_DATA, ASSOC_DATA_1, ASSOC_DATA_2, ASSOC_DATA_3, ASSOC_DATA_4, BIOG_ADDR_DATA, BIOG_INST_DATA, BIOG_SOURCE_DATA, ENTRY_DATA, KIN_DATA_1, KIN_DATA_2, POSTED_TO_ADDR_DATA, POSTED_TO_OFFICE_DATA, POSTING_DATA, STATUS_DATA, TEXT_DATA, BIOG_MAIN]


def get_list(id_list):
    output = []
    with open(id_list, "r", encoding="utf-8") as f:
        csv_handle = csv.reader(f, delimiter="\t")
        for row in csv_handle:
            output.append(row)
    return output

def generate_update_sqls(id_list):
    output = []
    for id_row in id_list:
        confirmed_id = id_row[0]
        to_remove_id = id_row[1]
        for sql_list_value in update_sql_list:
            output.append(sql_list_value%(confirmed_id, to_remove_id))
    return output

def generate_delete_sqls(id_list):
    output = []
    for id_row in id_list:
        to_remove_id = id_row[1]
        for sql_list_value in delete_sql_list:
            output.append(sql_list_value%(to_remove_id))
    return output

def output_data(output_file, update_sqls):
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(update_sqls)

# list format [confirmed_id, to_remove_id]
id_list = get_list("id_list.txt")
update_sqls = generate_update_sqls(id_list)
output_data("output_update_sqls.txt", "\n".join(update_sqls))
delete_sqls = generate_delete_sqls(id_list)
output_data("output_delete_sqls.txt", "\n".join(delete_sqls))

print("Done!")
